var language = {
		fr:
		{
			favTitle: "Mes vidéos favorites",
			themeTitle: "VIDÉOS SUR LE MÊME THEME",
			resumeTitle: "RÉSUMÉ",
		}
};